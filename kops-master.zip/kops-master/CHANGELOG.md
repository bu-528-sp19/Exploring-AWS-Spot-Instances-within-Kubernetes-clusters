Our change log is available [here](docs/releases/).
