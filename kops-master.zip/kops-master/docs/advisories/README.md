## kops Advisories

- [Spectre/Meltdown: Kernel Update Required](spectre-meltdown-kernel-update.md)
  - CVE-2017-5715
  - CVE-2017-5753
  - CVE-2017-5754

- [dnsmasq/kube-dns update required](cve_2017_14491.md)
  - CVE-2017-14491

