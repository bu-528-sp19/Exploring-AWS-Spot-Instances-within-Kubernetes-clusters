[Moved here](upgrade_from_kubeup.md)
