# GPU Support

You can use [kops hooks](./cluster_spec.md#hooks) to install [Nvidia kubernetes device plugin](https://github.com/NVIDIA/k8s-device-plugin) and enable GPU support in cluster.

See instructions in [kops hooks for nvidia-device-plugin](../hooks/nvidia-device-plugin).
