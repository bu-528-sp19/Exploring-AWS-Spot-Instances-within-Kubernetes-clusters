# Hack Directory

As a developer you need to go look at the scripts in the hack directory in the root of this repo.  Scripts like `dev-build.sh` will make your life much easier.
