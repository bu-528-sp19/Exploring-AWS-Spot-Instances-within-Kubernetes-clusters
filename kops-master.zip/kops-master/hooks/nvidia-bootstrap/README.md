## NVIDIA Driver Installation

The source code within this directory is provided under the [Apache License, version 2.0](https://www.apache.org/licenses/LICENSE-2.0).

Note that the NVIDIA software installed by this hook's container may be subject to [NVIDIA's own license terms](http://www.nvidia.com/content/DriverDownload-March2009/licence.php?lang=us).

This is an experimental hook for installing the nvidia drivers as part of the kops boot process.

Please see the [GPU docs](/docs/gpu.md) for more details on how to use this.