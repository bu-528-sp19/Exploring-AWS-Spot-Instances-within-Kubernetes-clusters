## Prepull images

This docker image can be used as a [kops hook](/docs/hooks.md) to pre-pull docker images.

The images to be pulled can be passed as arguments.  (TODO: Add example)