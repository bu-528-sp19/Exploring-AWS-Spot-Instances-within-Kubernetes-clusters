This docker image builds statically linked binaries, in particular socat and conntrack for use on CoreOS.
