## Usages
channels apply channel kube-state-metrics --yes
