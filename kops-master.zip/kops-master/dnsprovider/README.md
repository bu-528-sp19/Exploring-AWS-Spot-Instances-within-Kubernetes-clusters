This is a (partial) copy of federation/pkg/dnsprovider from k8s.io/kubernetes.

Changes made here should be submitted upstream.

Reasons for doing this:

* Ability to fix bugs quickly
* We want to stop vendoring k8s.io/kubernetes
* The federation code is likely to move somewhere else in future
