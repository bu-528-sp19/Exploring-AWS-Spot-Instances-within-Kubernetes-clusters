## Examples of how to embed kops / use the kops API

The kops API is still a work in progress, but this is where we will put examples of how it can be used.

```
make examples
```

```
kops-api-example -name api1.example.com -zones us-east-1c
```