---
name: Feature Request
about: Help us identify features you need
---

**1. Describe IN DETAIL the feature/behavior/change you would like to see.**

**2. Feel free to provide a design supporting your feature request.**
